import { useMemo, useState } from "react";

const GOOGLE_SCRIPT_URL = "PASTE_YOUR_GOOGLE_SCRIPT_URL_HERE";

export default function ReefscapeScoutApp() {
  const [activeTab, setActiveTab] = useState<"teleop" | "auto">("teleop");

  const [teamNumber, setTeamNumber] = useState("");
  const [matchNumber, setMatchNumber] = useState("");

  const emptyScore = {
    l1: 0,
    l2: 0,
    l3: 0,
    l4: 0,
    algaeNet: 0,
    algaeProcessor: 0,
  };

  const [teleop, setTeleop] = useState({ ...emptyScore });
  const [auto, setAuto] = useState({ ...emptyScore });

  const [climb, setClimb] = useState<"none" | "deep" | "shallow" | "park">("none");
  const [defenseRating, setDefenseRating] = useState(2);
  const [notes, setNotes] = useState("");

  const updateScore = (
    section: "teleop" | "auto",
    field: keyof typeof emptyScore,
    delta: number
  ) => {
    if (section === "teleop") {
      setTeleop((p) => ({ ...p, [field]: Math.max(0, p[field] + delta) }));
    } else {
      setAuto((p) => ({ ...p, [field]: Math.max(0, p[field] + delta) }));
    }
  };

  const totalPoints = useMemo(() => {
    const autoPoints =
      auto.l1 * 3 + auto.l2 * 4 + auto.l3 * 6 + auto.l4 * 7 +
      auto.algaeNet * 4 + auto.algaeProcessor * 6;

    const teleopPoints =
      teleop.l1 * 2 + teleop.l2 * 3 + teleop.l3 * 4 + teleop.l4 * 5 +
      teleop.algaeNet * 4 + teleop.algaeProcessor * 6;

    const climbPoints =
      climb === "deep" ? 12 : climb === "shallow" ? 6 : climb === "park" ? 2 : 0;

    return autoPoints + teleopPoints + climbPoints;
  }, [auto, teleop, climb]);

  const scoringFields: { key: keyof typeof emptyScore; label: string }[] = [
    { key: "l1", label: "L1" },
    { key: "l2", label: "L2" },
    { key: "l3", label: "L3" },
    { key: "l4", label: "L4" },
    { key: "algaeNet", label: "Algae Net" },
    { key: "algaeProcessor", label: "Algae Processor" },
  ];

  const currentData = activeTab === "teleop" ? teleop : auto;

  const submitData = async () => {
    const payload = {
      teamNumber,
      matchNumber,
      auto,
      teleop,
      defenseRating,
      climb,
      totalPoints,
      notes,
      timestamp: new Date().toISOString(),
    };

    try {
      await fetch(GOOGLE_SCRIPT_URL, {
        method: "POST",
        mode: "no-cors",
        body: JSON.stringify(payload),
      });
      alert("Saved to Google Sheets");
    } catch (e) {
      alert("Error saving data");
    }
  };

  const box: React.CSSProperties = {
    border: "1px solid #333",
    padding: 10,
    margin: 10,
    borderRadius: 10,
    background: "#1a1a1a",
  };

  return (
    <div
      style={{
        fontFamily: "Arial",
        background: "#0f0f0f",
        color: "white",
        minHeight: "100vh",
        display: "flex",
        justifyContent: "center",
        padding: 10,
      }}
    >
      {/* PORTRAIT CONTAINER */}
      <div
        style={{
          width: "100%",
          maxWidth: 420,
          background: "#111",
          borderRadius: 16,
          padding: 12,
        }}
      >
        <h2 style={{ textAlign: "center" }}>REEFSCAPE SCOUTING</h2>

        <div style={box}>
          <input
            style={{ width: "100%", marginBottom: 8, padding: 8 }}
            placeholder="Team Number"
            value={teamNumber}
            onChange={(e) => setTeamNumber(e.target.value)}
          />
          <input
            style={{ width: "100%", padding: 8 }}
            placeholder="Match Number"
            value={matchNumber}
            onChange={(e) => setMatchNumber(e.target.value)}
          />
        </div>

        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => setActiveTab("teleop")} style={{ flex: 1 }}>
            Teleop
          </button>
          <button onClick={() => setActiveTab("auto")} style={{ flex: 1 }}>
            Auto
          </button>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(2, 1fr)",
            gap: 8,
            marginTop: 10,
          }}
        >
          {scoringFields.map((f) => (
            <div key={f.key} style={box}>
              <h4>{f.label}</h4>
              <button onClick={() => updateScore(activeTab, f.key, -1)}>-</button>
              <span style={{ margin: 8 }}>{currentData[f.key]}</span>
              <button onClick={() => updateScore(activeTab, f.key, 1)}>+</button>
            </div>
          ))}
        </div>

        <div style={box}>
          <h4>Defense Rating</h4>
          <input
            type="number"
            min={0}
            max={4}
            value={defenseRating}
            onChange={(e) => setDefenseRating(Number(e.target.value))}
          />
        </div>

        <div style={box}>
          <h4>Climb</h4>
          <button onClick={() => setClimb("deep")}>Deep</button>
          <button onClick={() => setClimb("shallow")}>Shallow</button>
          <button onClick={() => setClimb("park")}>Park</button>
        </div>

        <div style={box}>
          <h2>Total: {totalPoints}</h2>
        </div>

        <textarea
          style={{ width: "100%", minHeight: 80 }}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Notes"
        />

        <button
          onClick={submitData}
          style={{
            width: "100%",
            padding: 14,
            borderRadius: 12,
            border: "none",
            background: "linear-gradient(135deg, #22c55e, #06b6d4)",
            color: "black",
            fontWeight: "bold",
            fontSize: 16,
            marginTop: 10,
          }}
        >
          Submit Match
        </button>
      </div>
    </div>
  );
}
